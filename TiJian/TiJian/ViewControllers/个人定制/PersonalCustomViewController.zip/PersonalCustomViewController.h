//
//  PersonalCustomViewController.h
//  TiJian
//
//  Created by lichaowei on 15/10/21.
//  Copyright © 2015年 lcw. All rights reserved.
//
/**
 *  个人定制
 */
#import "MyViewController.h"

@interface PersonalCustomViewController : MyViewController

@property(nonatomic,retain)NSString *vouchers_id;

@end
